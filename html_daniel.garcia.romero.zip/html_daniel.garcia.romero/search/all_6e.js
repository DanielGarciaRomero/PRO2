var searchData=
[
  ['name',['name',['../class_revista.html#a38d9359932c87fcf02097e4bc1482cf4',1,'Revista']]]
];
