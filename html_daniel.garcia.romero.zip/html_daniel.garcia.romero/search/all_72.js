var searchData=
[
  ['revista',['Revista',['../class_revista.html',1,'Revista'],['../class_revista.html#a4d3790c7da4821edc95e09f3c34b8332',1,'Revista::Revista()']]],
  ['revista_2ecpp',['Revista.cpp',['../_revista_8cpp.html',1,'']]],
  ['revista_2ehpp',['Revista.hpp',['../_revista_8hpp.html',1,'']]]
];
