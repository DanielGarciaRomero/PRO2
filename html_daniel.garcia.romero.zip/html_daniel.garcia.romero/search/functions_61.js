var searchData=
[
  ['anadir_5fpal_5fclave',['anadir_pal_clave',['../class_revista.html#a4936160691bc8b21a85b187f5222bf22',1,'Revista']]],
  ['anadir_5frevista',['anadir_revista',['../class_biblioteca.html#a7e79692a6aaf88f7d9531770b4b89e07',1,'Biblioteca']]],
  ['asignar_5farea_5fc1',['asignar_area_c1',['../class_revista.html#ae71c7c541f342465fc54f7ca40d3040b',1,'Revista']]],
  ['asignar_5farea_5fc2',['asignar_area_c2',['../class_revista.html#a1d1f617b79934eac5b2cacc8b69ca355',1,'Revista']]]
];
