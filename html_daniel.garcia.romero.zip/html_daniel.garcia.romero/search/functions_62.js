var searchData=
[
  ['biblioteca',['Biblioteca',['../class_biblioteca.html#a021f69adcc57a5d04e6e12532a684e2b',1,'Biblioteca']]],
  ['busca_5fbiblio',['busca_biblio',['../class_biblioteca.html#a9e998c247690bc610d7c62e4702b7050',1,'Biblioteca']]],
  ['busca_5fbiblio2',['busca_biblio2',['../class_biblioteca.html#acbf502a9340cb664f5f02f8eb3fcbf10',1,'Biblioteca']]]
];
