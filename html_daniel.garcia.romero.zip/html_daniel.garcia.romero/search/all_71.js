var searchData=
[
  ['quality',['quality',['../class_revista.html#a4a211fb36fff3f8888d24f0c7fec48be',1,'Revista']]]
];
