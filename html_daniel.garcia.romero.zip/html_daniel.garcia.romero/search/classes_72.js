var searchData=
[
  ['revista',['Revista',['../class_revista.html',1,'']]]
];
