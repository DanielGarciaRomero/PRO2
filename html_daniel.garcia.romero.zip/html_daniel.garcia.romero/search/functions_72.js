var searchData=
[
  ['revista',['Revista',['../class_revista.html#a4d3790c7da4821edc95e09f3c34b8332',1,'Revista']]]
];
