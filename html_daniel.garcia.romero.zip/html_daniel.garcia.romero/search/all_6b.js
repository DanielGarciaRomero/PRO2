var searchData=
[
  ['keywords',['keywords',['../class_revista.html#aa358fa42c086551f182105ae0abdfafc',1,'Revista']]]
];
