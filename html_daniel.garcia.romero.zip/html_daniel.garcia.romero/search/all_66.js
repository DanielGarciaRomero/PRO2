var searchData=
[
  ['fusionar_5frevistas',['fusionar_revistas',['../class_biblioteca.html#a7cb270b9e3a2217d57116f9d15fc4057',1,'Biblioteca']]]
];
