var searchData=
[
  ['calcular_5farea_5fc1',['calcular_area_c1',['../class_jerarquiarea.html#a7ea6343c6e76a3be0d1e0248dcaaff90',1,'Jerarquiarea']]],
  ['calcular_5farea_5fc2',['calcular_area_c2',['../class_jerarquiarea.html#af149665676225b77b1384c38dae95564',1,'Jerarquiarea']]],
  ['consultar_5farea_5fc1',['consultar_area_c1',['../class_revista.html#af222d50f9669b15e50aca35a91b04d14',1,'Revista']]],
  ['consultar_5farea_5fc2',['consultar_area_c2',['../class_revista.html#aa78e310c2652c9b468c2d4c0152ade58',1,'Revista']]],
  ['consultar_5fcalidad',['consultar_calidad',['../class_revista.html#ad58bb71f4e958bf0f5bd20ab66770434',1,'Revista']]],
  ['consultar_5fnombre',['consultar_nombre',['../class_revista.html#ac10527d8baaf1600765e90a81590de7a',1,'Revista']]],
  ['consultar_5fnum_5fpal_5fclave',['consultar_num_pal_clave',['../class_revista.html#aa29116f0d4be72289882293acad7ec88',1,'Revista']]],
  ['consultar_5fpal_5fclave',['consultar_pal_clave',['../class_revista.html#aa55ba12ab70973779e1229f441cb9df8',1,'Revista']]],
  ['consultar_5frevista',['consultar_revista',['../class_biblioteca.html#ae95bfaa2a0c796c59096c1b26c7bc8c0',1,'Biblioteca']]]
];
