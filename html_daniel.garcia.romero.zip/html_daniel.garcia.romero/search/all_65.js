var searchData=
[
  ['eliminar_5frevista',['eliminar_revista',['../class_biblioteca.html#ae17682bc188d1f6c163d71387e8a9f6e',1,'Biblioteca']]]
];
