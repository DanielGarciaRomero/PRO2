var searchData=
[
  ['biblio',['biblio',['../class_biblioteca.html#a5e237c8f8a238cbe70609ed19e5b23a1',1,'Biblioteca']]],
  ['biblio2',['biblio2',['../class_biblioteca.html#a40d86ccd03ced2cb9ad177a1951b8e3f',1,'Biblioteca']]]
];
