var searchData=
[
  ['biblio',['biblio',['../class_biblioteca.html#a5e237c8f8a238cbe70609ed19e5b23a1',1,'Biblioteca']]],
  ['biblio2',['biblio2',['../class_biblioteca.html#a40d86ccd03ced2cb9ad177a1951b8e3f',1,'Biblioteca']]],
  ['biblioteca',['Biblioteca',['../class_biblioteca.html',1,'Biblioteca'],['../class_biblioteca.html#a021f69adcc57a5d04e6e12532a684e2b',1,'Biblioteca::Biblioteca()']]],
  ['biblioteca_2ecpp',['Biblioteca.cpp',['../_biblioteca_8cpp.html',1,'']]],
  ['biblioteca_2ehpp',['Biblioteca.hpp',['../_biblioteca_8hpp.html',1,'']]],
  ['busca_5fbiblio',['busca_biblio',['../class_biblioteca.html#a9e998c247690bc610d7c62e4702b7050',1,'Biblioteca']]],
  ['busca_5fbiblio2',['busca_biblio2',['../class_biblioteca.html#acbf502a9340cb664f5f02f8eb3fcbf10',1,'Biblioteca']]]
];
