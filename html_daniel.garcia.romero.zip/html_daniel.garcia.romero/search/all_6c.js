var searchData=
[
  ['leer_5farbol',['leer_arbol',['../class_jerarquiarea.html#ae2f71dfdb64b28bac9d6dda3a3d4fe68',1,'Jerarquiarea']]],
  ['leer_5fjerarquia',['leer_jerarquia',['../class_jerarquiarea.html#a69296ade8a3369b69db7d1b31e2d970a',1,'Jerarquiarea']]],
  ['leer_5frevista',['leer_revista',['../class_revista.html#a61178cb7b236db9a3354d5d00df1b31b',1,'Revista']]],
  ['listado',['listado',['../class_biblioteca.html#af8acc2e2c5f39400347c18323ecc4f23',1,'Biblioteca']]]
];
