var searchData=
[
  ['a',['a',['../class_jerarquiarea.html#ac14363439f2c43a7e71c505d0d812843',1,'Jerarquiarea']]],
  ['area_5fc1',['area_c1',['../class_revista.html#a4f094a49907934fa5641fc5f024148f8',1,'Revista']]],
  ['area_5fc2',['area_c2',['../class_revista.html#a8db3539ee9d73acd85ebe645f0f2dd15',1,'Revista']]]
];
